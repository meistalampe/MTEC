%% description

%   title:          ECGAnalysisMain.m
%   author:         David Thinnes
%   last change:    15.02.2018
%   description:    this program gets an raw ecg data vector,
%                   the belonging time vector(both with the same length).
%                   It detrends the data, filters it and uses
%                   geometrical(poincare) and spectral(lomb) analysis
%                   methods to visualize artefacts and HRV.


clc;
clear;
close all;  
addpath(genpath('../'));


prompt = {'Enter signal vector:','Enter signal time vector',...
          'Enter Sampling Frequency:','Enter path to saving figures'};
dlg_title = 'Input';
num_lines = 1;
answer = inputdlg(prompt,dlg_title,num_lines);

fprintf('Processing...\n');
% answers
signalname = answer{1,1};
time = answer{2,1};
Fs = str2double(answer{3,1});
filepath = answer{4,1};

% load data
signal = load(signalname);
signal = struct2cell(signal);
signal = signal{1,1};
time = load(time);
time = struct2cell(time);
time = time{1,1};

% call filtering ecg
ecgfilter = filterECG( signal,time ,Fs,filepath);
% call function heartrate 
[ heartrate,MeanRR,SDNN,RMSSD,mean_heartrate,std_heartrate,heartrate_coe,peakInterval,peakInterval_time ] = heartrate(ecgfilter,time,Fs,filepath);
% call function ellipse
ellipse( peakInterval_time,filepath);

% Saving workspace
resultsFilename = 'results';

% clear runtime variables
clear dlg_title num_lines prompt 
fprintf('Saving analysis results to file ... ');

save([filepath filesep resultsFilename '.mat'], '-v7.3');
fprintf('Done.\n');



